"""Virtual-time object replicas and service queues for a single simulated drive."""

from __future__ import annotations

import heapq
import itertools
import math
from collections import Counter, OrderedDict
from dataclasses import dataclass, field

MIB = 1 << 20


class Clock:
    def __init__(self):
        self.now = 0
        self.events = []
        self._sequence = itertools.count()

    def at(self, when, callback, *args):
        if when < self.now:
            raise ValueError("Cannot enqueue in the past")
        heapq.heappush(self.events, (when, next(self._sequence), callback, args))

    def advance(self, until):
        if until < self.now:
            raise ValueError("Clock moved backwards")
        while self.events and self.events[0][0] <= until:
            self.now, _, callback, args = heapq.heappop(self.events)
            callback(*args)
        self.now = until


@dataclass(frozen=True)
class StoreConfig:
    clients: int
    segment_bytes: int
    staging_bytes: int
    quota_bytes: int
    offload_delay_ms: float = 1000
    device_mib_s: float = 1024
    memory_mib_s: float = 8192
    lease_ms: float = 0
    save_ms: float = 1
    high_watermark: float = 0.90
    eviction_ratio: float = 0.05

    def __post_init__(self):
        if self.clients not in (1, 8) or any(
            type(v) is not int or v <= 0
            for v in (self.segment_bytes, self.staging_bytes, self.quota_bytes)
        ):
            raise ValueError("Expected 1 or 8 clients with positive per-client byte budgets")
        for v in (self.offload_delay_ms, self.lease_ms, self.save_ms):
            if not math.isfinite(v) or v < 0:
                raise ValueError("Delay must be finite and nonnegative")
        if not 0 < self.eviction_ratio < self.high_watermark <= 1:
            raise ValueError("Expected 0 < eviction ratio < high watermark <= 1")
        for v in (self.device_mib_s, self.memory_mib_s):
            if not math.isfinite(v) or v <= 0:
                raise ValueError("Service rates must be finite and positive")


@dataclass
class Client:
    memory: OrderedDict = field(default_factory=OrderedDict)
    disk: OrderedDict = field(default_factory=OrderedDict)
    memory_bytes: int = 0
    disk_bytes: int = 0  # includes space reserved for pending writes
    peak_memory_bytes: int = 0
    peak_disk_bytes: int = 0
    peak_staging_bytes: int = 0
    memory_free_at: int = 0
    reclaim_to: int | None = None


@dataclass
class Replica:
    key: str
    size: int
    owner: int
    memory: bool = True
    disk: bool = False
    readers: int = 0
    lease_until: int = 0


class ObjectStore:
    """Eager offload, writer-owned placement, byte quotas and eligible-LRU eviction.

    These policies and the shared FIFO device are explicit experiment parameters/
    assumptions. Layout and lookup decisions live in the native connector.
    """

    def __init__(self, clock, config, emit):
        self.clock, self.config, self.emit = clock, config, emit
        self.clients = [Client() for _ in range(config.clients)]
        self.objects = {}
        self.inventory = {}
        self.counts = Counter()
        self.bytes = Counter()
        self.disk_free_at = 0

    def record(self, op, obj, origin, **extra):
        self.counts[op] += 1
        self.bytes[op] += obj.size
        self.emit(op, key=obj.key, bytes=obj.size, owner=obj.owner, **origin, **extra)

    def batch_is_exist(self, keys):
        return [int(k in self.objects) for k in keys]

    def _evict(self, client, tier, required, origin):
        cache = getattr(client, tier)
        used = tier + "_bytes"
        limit = self.config.segment_bytes if tier == "memory" else self.config.quota_bytes
        if required > limit:
            return False
        if getattr(client, used) + required <= limit:
            return True
        for key in list(cache):
            obj = self.objects[key]
            if obj.readers or self.clock.now < obj.lease_until:
                continue
            if tier == "memory" and not obj.disk:
                continue  # retain source through disk publication
            cache.pop(key)
            setattr(obj, tier, False)
            setattr(client, used, getattr(client, used) - obj.size)
            self.record("evict_" + tier, obj, origin)
            if not obj.memory and not obj.disk:
                del self.objects[key]
            if getattr(client, used) + required <= limit:
                return True
        return False

    def _trim_memory(self, client, origin):
        capacity = self.config.segment_bytes
        if (
            client.reclaim_to is None
            and client.memory_bytes > self.config.high_watermark * capacity
        ):
            client.reclaim_to = max(
                0, client.memory_bytes - math.ceil(capacity * self.config.eviction_ratio)
            )
        if client.reclaim_to is not None and self._evict(
            client, "memory", capacity - client.reclaim_to, origin
        ):
            client.reclaim_to = None

    def drop_published_memory(self, origin):
        """Controlled disk-only probe boundary after publication and before any read."""
        for client in self.clients:
            if not self._evict(client, "memory", self.config.segment_bytes, origin):
                raise ValueError("Could not establish the disk-only probe boundary")

    def put(self, key, size, origin):
        if self.inventory.get(key, size) != size:
            raise ValueError(f"Size changed for immutable key {key}")
        if key in self.objects:
            return 0
        owner = origin["rank"] % self.config.clients
        obj = Replica(key, size, owner)
        client = self.clients[owner]
        if not self._evict(client, "memory", size, origin):
            self.record("put_rejected", obj, origin)
            return -200  # native connector's no-available-handle path
        self.objects[key] = obj
        self.inventory[key] = size
        client.memory[key] = None
        client.memory_bytes += size
        client.peak_memory_bytes = max(client.peak_memory_bytes, client.memory_bytes)
        self.record("put_complete", obj, origin)
        self._trim_memory(client, origin)
        self.clock.at(
            self.clock.now + round(self.config.offload_delay_ms * 1e6),
            self._queue_write,
            obj,
            origin,
        )
        return 0

    def _device_io(self, op, obj, origin, staging_client, done):
        start = max(self.disk_free_at, self.clock.now)
        end = start + math.ceil(obj.size * 1e9 / (self.config.device_mib_s * MIB))
        self.disk_free_at = end
        self.record(op + "_submit", obj, origin, staging_client=staging_client)
        client = self.clients[staging_client]

        def begin():
            client.peak_staging_bytes = max(client.peak_staging_bytes, obj.size)
            self.record(op + "_start", obj, origin, staging_client=staging_client)

        self.clock.at(start, begin)
        self.clock.at(end, done, obj, origin)
        return end

    def _queue_write(self, obj, origin):
        client = self.clients[obj.owner]
        if obj.size > self.config.staging_bytes or not self._evict(
            client, "disk", obj.size, origin
        ):
            self.record("offload_rejected", obj, origin)
            return
        client.disk_bytes += obj.size
        client.peak_disk_bytes = max(client.peak_disk_bytes, client.disk_bytes)
        self._device_io("disk_write", obj, origin, obj.owner, self._publish)

    def _publish(self, obj, origin):
        obj.disk = True
        self.clients[obj.owner].disk[obj.key] = None
        self.record("disk_publish", obj, origin)
        self._trim_memory(self.clients[obj.owner], origin)

    def get(self, key, size, origin):
        obj = self.objects[key]
        if obj.size != size:
            raise ValueError(f"Restore descriptor differs for {key}")
        obj.readers += 1
        obj.lease_until = max(obj.lease_until, self.clock.now + round(self.config.lease_ms * 1e6))
        client = self.clients[obj.owner]
        tier = "memory" if obj.memory else "disk"
        getattr(client, tier).move_to_end(key)
        self.record("get_" + tier, obj, origin)
        if tier == "disk":
            if size > self.config.staging_bytes:
                raise ValueError("Object exceeds GET staging budget")
            return self._device_io(
                "disk_read", obj, origin, origin["rank"] % self.config.clients, self._finish_get
            )
        end = max(self.clock.now, client.memory_free_at) + math.ceil(
            size * 1e9 / (self.config.memory_mib_s * MIB)
        )
        client.memory_free_at = end
        self.clock.at(end, self._finish_get, obj, origin)
        return end

    def _finish_get(self, obj, origin):
        obj.readers -= 1
        self.record("get_complete", obj, origin)

    def summary(self):
        return {
            "unique_keys": len(self.inventory),
            "unique_logical_bytes": sum(self.inventory.values()),
            "counts": dict(self.counts),
            "bytes": dict(self.bytes),
            "clients": [
                {
                    "id": index,
                    "memory_bytes": c.memory_bytes,
                    "disk_bytes": c.disk_bytes,
                    "peak_memory_bytes": c.peak_memory_bytes,
                    "peak_disk_bytes": c.peak_disk_bytes,
                    "peak_staging_bytes": c.peak_staging_bytes,
                }
                for index, c in enumerate(self.clients)
            ],
        }
