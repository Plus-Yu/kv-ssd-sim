"""Drive the pinned Mooncake connector's save, lookup and load code on tensor metadata."""

from __future__ import annotations

import threading
from collections import Counter
from contextlib import contextmanager
from unittest.mock import patch

import torch
from vllm.config import set_current_vllm_config
from vllm.distributed.kv_transfer.kv_connector.v1.mooncake_store import scheduler as mc_scheduler
from vllm.distributed.kv_transfer.kv_connector.v1.mooncake_store import worker as mc_worker
from vllm.distributed.kv_transfer.kv_connector.v1.mooncake_store.coordinator import (
    MooncakeStoreCoordinator,
)
from vllm.v1.core.sched.scheduler import Scheduler
from vllm.v1.core.single_type_kv_cache_manager import register_all_kvcache_specs
from vllm.v1.kv_cache_interface import KVCacheConfig
from vllm.v1.outputs import KVConnectorOutput
from vllm.v1.structured_output import StructuredOutputManager

from .k3_online import metadata_rank_worker
from .native import scheduler_config


class RankPort:
    """Descriptor-only Store API. Addresses returned by meta tensors are never dereferenced."""

    def __init__(self, store, rank):
        self.store = store
        self.rank = rank
        self.done_at = 0

    def bind(self, meta):
        self.meta = meta
        self.boundaries = {h.hex(): (i + 1) * self.unit for i, h in enumerate(meta.block_hashes)}
        self.done_at = self.store.clock.now

    def origin(self, key):
        _, group, digest = key.rsplit("@", 2)
        return {
            "request": self.meta.req_id,
            "rank": self.rank,
            "job": self.meta.store_job_id,
            "group": int(group.removeprefix("group:")),
            "boundary_tokens": self.boundaries[digest],
        }

    def batch_is_exist(self, keys):
        return self.store.batch_is_exist(keys)

    def batch_put_from_multi_buffers(self, keys, addresses, sizes, config):
        return [self.store.put(k, sum(s), self.origin(k)) for k, s in zip(keys, sizes, strict=True)]

    def batch_get_into_multi_buffers(self, keys, addresses, sizes):
        result = []
        for k, s in zip(keys, sizes, strict=True):
            size = sum(s)
            end = self.store.get(k, size, self.origin(k))
            self.done_at = max(self.done_at, end)
            result.append(size)
        return result


class MetadataRank:
    def __init__(self, store, groups, geometry, coord, rank, blocks, model_name, prefix):
        self.store = store
        self.clock = store.clock
        self.port = RankPort(store, rank)
        block, unit = geometry["manager_block_tokens"], geometry["hash_tokens"]
        self.port.unit = unit
        w = self.worker = metadata_rank_worker(groups, unit, rank, model_name, prefix)
        w.store, w.coord, w._capacity_only, w._selective_lease = self.port, coord, False, None
        w.kv_connector_stats = mc_worker.MooncakeStoreConnectorStats()
        w._kv_connector_stats_lock = threading.Lock()
        w.finished_store_req = set()
        # Shape, dtype and stride match K3Buffers. Meta tensors have no payload storage.
        page = geometry["common_page_bytes"]
        for group, db in zip(groups, w.token_dbs, strict=True):
            width = group.kv_cache_spec.real_page_size_bytes
            states = block if db.store_layout.store_format == "attention_head_major" else 1
            tensor = torch.empty((blocks, page), dtype=torch.uint8, device="meta")
            view = tensor[:, :width].view(blocks, 1, states, -1)
            db.store_layout.register_kv_caches([view] * len(group.layer_names), blocks)

        w.kv_send_thread = self.sender = mc_worker.KVCacheStoreSendingThread(
            self.port,
            coord,
            w.token_dbs,
            block,
            rank,
            w._group_tp_replication_factors,
            "kv_both",
            threading.Event(),
        )
        self.receiver = mc_worker.KVCacheStoreRecvingThread(
            self.port,
            coord,
            w.token_dbs,
            block,
            rank,
            threading.Event(),
            disk_offload_buffer_budget_bytes=store.config.staging_bytes,
        )
        self.save_tail = 0

    def enqueue_save(self, meta, compute_end):
        self.sender.add_request(meta)
        start = max(compute_end, self.save_tail)
        self.save_tail = start + round(self.store.config.save_ms * 1e6)
        self.store.emit(
            "save_queued",
            request=meta.req_id,
            rank=self.port.rank,
            job=meta.store_job_id,
            start_ns=start,
            complete_ns=self.save_tail,
        )
        self.clock.at(self.save_tail, self._save, meta)

    def _save(self, meta):
        if self.sender.request_queue.get_nowait() is not meta:
            raise ValueError("Per-rank save queue reordered")
        self.port.bind(meta)
        self.sender._handle_request(meta)
        self.store.emit("save_ack", request=meta.req_id, rank=self.port.rank, job=meta.store_job_id)

    def load(self, meta):
        meta.load_spec.token_len = meta.load_spec.kvpool_cached_tokens
        self.port.bind(meta)
        self.receiver.add_request(meta)
        self.receiver._handle_request(self.receiver.request_queue.get_nowait())
        if (
            self.receiver.get_and_clear_finished_requests() != {meta.req_id}
            or self.receiver.get_and_clear_block_ids_with_load_errors()
            or self.receiver.get_and_clear_failed_requests()
        ):
            raise ValueError(f"Native load failed for {meta.req_id}")
        return self.port.done_at


class MetadataTransfers:
    def __init__(self, ranks):
        self.ranks = ranks
        self.receive_acks = set()

    def submit(self, metadata, finished, compute_end):
        for rank in self.ranks:
            rank.worker._close_ended_store_requests(finished, metadata)
        external = Counter()
        for meta in metadata.requests:
            if meta.can_save:
                for rank in self.ranks:
                    rank.enqueue_save(meta, compute_end)
            if meta.load_spec is not None and meta.load_spec.can_load:
                external[meta.req_id] += (
                    meta.load_spec.kvpool_cached_tokens - meta.load_spec.vllm_cached_tokens
                )
                last = max(rank.load(meta) for rank in self.ranks)
                self.ranks[0].clock.at(last, self.receive_acks.add, meta.req_id)
        return external

    def output(self):
        counts = Counter()
        for rank in self.ranks:
            counts.update(rank.sender.take_completed_saves())
        ready = self.receive_acks.copy()
        self.receive_acks.clear()
        return KVConnectorOutput(
            finished_recving=ready,
            finished_sending=set(),
            kv_connector_worker_meta=mc_worker.MooncakeStoreWorkerMetadata(
                completed_saves=dict(counts)
            ),
        )


class InProcessLookup:
    """Synchronous scheduler lookup with the native rank-0 cross-rank completeness checks."""

    def __init__(self, reader):
        self.reader = reader

    def lookup(self, request_id, num_tokens, block_hashes, *, non_block):
        if non_block:
            raise ValueError("Expected synchronous native prefix lookup")
        result = self.reader.lookup(num_tokens, block_hashes)
        self.reader.store.store.emit(
            "prefix_lookup",
            request=request_id,
            lookup_tokens=num_tokens,
            hit_tokens=result.hit_length,
            tail_key_boundaries=[(b.group_id, b.num_tokens) for b in result.tail_key_boundaries],
        )
        return result

    def discard(self, request_id):
        pass  # No RPC result cache.


@contextmanager
def metadata_scheduler(store, plan, groups, blocks, max_length):
    geometry = plan["geometry"]
    block, unit = geometry["manager_block_tokens"], geometry["hash_tokens"]
    config = scheduler_config(max_length, block, k3=True)
    cache = config.cache_config
    cache.kv_cache_layout = "LBHNC"
    cache.prefix_match_unit = cache.hash_block_size = cache.cache_hit_alignment_tokens = unit
    cache.num_gpu_blocks = blocks
    config.parallel_config.world_size = 8
    allocation = KVCacheConfig(num_blocks=blocks, kv_cache_groups=groups, kv_cache_tensors=[])
    with set_current_vllm_config(config):
        register_all_kvcache_specs(config)
        coord = MooncakeStoreCoordinator.from_kv_cache_config(allocation, config, block, unit)
        ranks = [
            MetadataRank(store, groups, geometry, coord, rank, blocks, "model", "k3-online-tp8")
            for rank in range(8)
        ]
        with patch.object(
            mc_scheduler, "LookupKeyClient", return_value=InProcessLookup(ranks[0].worker)
        ):
            scheduler = Scheduler(
                vllm_config=config,
                kv_cache_config=allocation,
                block_size=block,
                hash_block_size=unit,
                log_stats=False,
                structured_output_manager=StructuredOutputManager(config),
            )
        yield scheduler, MetadataTransfers(ranks)
