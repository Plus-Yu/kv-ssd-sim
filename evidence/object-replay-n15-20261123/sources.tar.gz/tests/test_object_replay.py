import asyncio
import json
from types import SimpleNamespace

import pytest

from kv_ssd_sim.object_store import Clock, ObjectStore, StoreConfig
from kv_ssd_sim.object_traffic import describe_traffic


def test_pending_publication_lease_and_capacity():
    clock = Clock()
    store = ObjectStore(
        clock, StoreConfig(1, 100, 100, 100, lease_ms=20, high_watermark=1), lambda *a, **k: None
    )
    origin = {"rank": 0, "request": "a"}
    assert store.put("a", 80, origin) == 0
    assert store.batch_is_exist(["a", "b"]) == [1, 0]
    assert store.put("b", 80, origin) < 0  # pending write still needs the only memory copy
    while clock.events:
        clock.advance(clock.events[0][0])
    first_get = clock.now
    clock.advance(store.get("a", 80, origin))
    assert store.put("b", 80, origin) < 0  # transfer finished but its lease is still active
    clock.advance(first_get + 20_000_000)
    assert store.put("b", 80, origin) == 0
    assert not store.objects["a"].memory and store.objects["a"].disk
    stop = store.get("a", 80, origin)
    assert store.counts["get_disk"] == 1 and store.objects["a"].readers == 1
    clock.advance(stop)
    while clock.events:
        clock.advance(clock.events[0][0])
    assert store.batch_is_exist(["a", "b"]) == [0, 1]
    assert store.summary()["clients"][0]["peak_disk_bytes"] <= 100


def test_shared_drive_serializes_clients_and_preserves_distinct_readers():
    clock = Clock()
    events = []
    store = ObjectStore(
        clock,
        StoreConfig(8, 100, 100, 100, offload_delay_ms=0),
        lambda op, **e: events.append((op, clock.now, e)),
    )
    for rank in [0, 7]:
        store.put(str(rank), 80, {"rank": rank})
    while clock.events:
        clock.advance(clock.events[0][0])
    ordered = [(op, t) for op, t, _ in events if op in ("disk_publish", "disk_write_start")]
    assert ordered[1][0] == "disk_publish" and ordered[1][1] == ordered[2][1]
    assert [c.disk_bytes for c in store.clients] == [80, 0, 0, 0, 0, 0, 0, 80]


def test_exact_reuse_distance_in_bytes(tmp_path):
    source = tmp_path / "events.jsonl"
    rows = [("a", "r1", 100), ("b", "r1", 20), ("c", "r2", 30), ("b", "r2", 20), ("a", "r3", 100)]
    source.write_text(
        "".join(
            json.dumps(
                {
                    "event": "put_complete" if i < 3 else "get_memory",
                    "key": k,
                    "bytes": n,
                    "request": r,
                    "time_ns": i,
                }
            )
            + "\n"
            for i, (k, r, n) in enumerate(rows)
        )
    )
    out = tmp_path / "reuse.jsonl"
    traffic, count = describe_traffic(source, out, len(rows))
    assert [
        json.loads(line)["distinct_intervening_bytes"] for line in out.read_text().splitlines()
    ] == [30, 50]
    assert traffic["r3"]["bytes"] == {"get_memory": 100} and count == 2


def test_load_ack_survives_multiple_scheduler_polls():
    pytest.importorskip("vllm")
    from kv_ssd_sim.object_worker import MetadataTransfers

    clock = Clock()
    rank = SimpleNamespace(
        clock=clock,
        worker=SimpleNamespace(_close_ended_store_requests=lambda *a: None),
        sender=SimpleNamespace(take_completed_saves=dict),
        load=lambda _: 100,
    )
    transfers = MetadataTransfers([rank])
    meta = SimpleNamespace(
        requests=[
            SimpleNamespace(
                req_id="r",
                can_save=False,
                load_spec=SimpleNamespace(
                    can_load=True, kvpool_cached_tokens=1536, vllm_cached_tokens=0
                ),
            )
        ]
    )
    assert transfers.submit(meta, set(), 0) == {"r": 1536}
    assert not transfers.output().finished_recving
    clock.advance(100)
    assert transfers.output().finished_recving == {"r"}
    assert not transfers.output().finished_recving


def test_native_shutdown_detects_errors_from_last_async_put():
    from kv_ssd_sim.server import ServingLoop

    async def close():
        store = SimpleNamespace(errors=[], femu_device=None)

        async def drain():
            store.errors.append("late PUT failure")

        loop = SimpleNamespace(
            task=asyncio.create_task(drain()),
            failure=None,
            cold=False,
            runtime=SimpleNamespace(store=store, workers=[]),
            engine=SimpleNamespace(metrics={}),
        )
        await ServingLoop.close(loop)

    with pytest.raises(RuntimeError, match="late PUT failure"):
        asyncio.run(close())
