"""Run K3 object-level predictions on compiled WEKA sessions with no KV payload allocation."""

import argparse
import hashlib
import json
import math
import os
from collections import defaultdict, deque
from dataclasses import asdict
from importlib.metadata import version
from pathlib import Path

from kv_ssd_sim.object_store import MIB, Clock, ObjectStore, StoreConfig
from kv_ssd_sim.object_traffic import describe_traffic
from kv_ssd_sim.runtime import PROJECT_ROOT as ROOT


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Admissions:
    """Release an arrival after every predecessor edge and its own delay are satisfied."""

    def __init__(self, inputs, offsets, clock, limit):
        self.clock = clock
        self.rows = {}
        self.followers = defaultdict(list)
        self.gates = {}
        self.release_time = {}
        self.ready = deque()
        trace_ids = set()
        for path, offset in zip(inputs, offsets, strict=True):
            data = json.loads(path.read_bytes())
            if data["schema"] != 1 or data["trace_id"] in trace_ids:
                raise ValueError("Expected compiled inputs with distinct local trace IDs")
            trace_ids.add(data["trace_id"])
            for row in data["requests"]:
                rid = row["id"]
                if rid in self.rows or not row["tokens"] or row["output_tokens"] < 1:
                    raise ValueError(f"Duplicate or empty request {rid}")
                if len(row["tokens"]) + row["output_tokens"] > limit:
                    raise ValueError(f"{rid} exceeds configured context/pool limit {limit}")
                if any(type(t) is not int or not 4 <= t < 32000 for t in row["tokens"]):
                    raise ValueError("Invalid compiled synthetic token IDs")
                digest = hashlib.sha256(
                    b"".join(t.to_bytes(4, "big") for t in row["tokens"])
                ).hexdigest()
                if digest != row["prompt_sha256"]:
                    raise ValueError(f"Token digest mismatch for {rid}")
                self.rows[rid] = row
                edges = row["dependencies"]
                self.gates[rid] = len(edges)
                root_ms = row["root_arrival_ms"]
                if not math.isfinite(root_ms) or root_ms < 0:
                    raise ValueError("Invalid root arrival time")
                self.release_time[rid] = round((offset * 1000 + root_ms) * 1e6)
                for parent, marker, delay in edges:
                    if marker not in ("start", "finish") or not math.isfinite(delay) or delay < 0:
                        raise ValueError("Invalid causal edge")
                    self.followers[parent, marker].append((rid, round(delay * 1e6)))
                if not edges:
                    clock.at(self.release_time[rid], self.arrive, rid)
        if not self.rows or any(parent not in self.rows for parent, _ in self.followers):
            raise ValueError("Empty workload or unresolved predecessor")

    def arrive(self, rid):
        self.ready.append(rid)
        self.notify(rid, "start")

    def notify(self, parent, marker):
        for rid, delay in self.followers.pop((parent, marker), []):
            self.release_time[rid] = max(self.release_time[rid], self.clock.now + delay)
            self.gates[rid] -= 1
            if not self.gates[rid]:
                self.clock.at(self.release_time[rid], self.arrive, rid)


def simulate(admissions, scheduler, transfers, store, hash_unit, prefill_ms, decode_ms):
    from vllm.sampling_params import SamplingParams
    from vllm.utils.hashing import sha256
    from vllm.v1.core.kv_cache_utils import get_request_block_hasher, init_none_hash
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import Request

    from kv_ssd_sim.payload import SYNTHETIC_TOKEN

    init_none_hash(sha256)
    hasher = get_request_block_hasher(hash_unit, sha256)
    clock = store.clock
    live, metrics = {}, {}
    idle_steps = 0
    while clock.events or admissions.ready or scheduler.has_requests():
        clock.advance(clock.now)
        while admissions.ready:
            rid = admissions.ready.popleft()
            row = admissions.rows[rid]
            params = SamplingParams(max_tokens=row["output_tokens"], ignore_eos=True, temperature=0)
            params.update_from_generation_config({}, 2)
            request = Request(
                request_id=rid,
                prompt_token_ids=row["tokens"],
                sampling_params=params,
                pooling_params=None,
                block_hasher=hasher,
            )
            live[rid] = request
            metrics[rid] = {
                "id": rid,
                "session": row["session"],
                "source_index": row["source_index"],
                "arrival_ns": admissions.release_time[rid],
                "admitted_ns": clock.now,
                "prompt_tokens": len(row["tokens"]),
                "prompt_sha256": row["prompt_sha256"],
                "output_tokens": row["output_tokens"],
                "computed_prompt_tokens": 0,
                "external_load_tokens": 0,
                "local_reuse_tokens": None,
            }
            scheduler.add_request(request)
            store.emit("request_admitted", request=rid)
            clock.advance(clock.now)
        if scheduler.has_requests():
            scheduled = scheduler.schedule()
            ranges = {
                rid: (live[rid].num_computed_tokens - count, live[rid].num_computed_tokens)
                for rid, count in scheduled.num_scheduled_tokens.items()
            }
            durations = [
                prefill_ms if a < live[r].num_prompt_tokens else decode_ms
                for r, (a, _) in ranges.items()
            ]
            end_ns = clock.now + round(max(durations, default=0) * 1e6)
            loads = transfers.submit(
                scheduled.kv_connector_metadata, scheduled.finished_req_ids, end_ns
            )
            for rid, count in loads.items():
                metrics[rid]["external_load_tokens"] += count
            for rid, (a, b) in ranges.items():
                m = metrics[rid]
                if m["local_reuse_tokens"] is None:
                    m["local_reuse_tokens"] = a - m["external_load_tokens"]
                m["computed_prompt_tokens"] += max(0, min(b, m["prompt_tokens"]) - a)
            clock.advance(end_ns)
            replies = transfers.output()
            result = ModelRunnerOutput(
                req_ids=list(ranges),
                kv_connector_output=replies,
                sampled_token_ids=[
                    [SYNTHETIC_TOKEN] if b >= live[r].num_prompt_tokens else []
                    for r, (_, b) in ranges.items()
                ],
            )
            scheduler.update_from_output(scheduled, result)
            for rid in ranges:
                if not live[rid].is_finished():
                    continue
                request = live.pop(rid)
                m = metrics[rid]
                if request.num_output_tokens != m["output_tokens"] or (
                    not request.num_preemptions
                    and m["local_reuse_tokens"]
                    + m["external_load_tokens"]
                    + m["computed_prompt_tokens"]
                    != m["prompt_tokens"]
                ):
                    raise ValueError(f"Token accounting failed for {rid}")
                m.update(finished_ns=clock.now, preemptions=request.num_preemptions)
                store.emit("request_finished", request=rid)
                admissions.notify(rid, "finish")
            if (
                ranges
                or loads
                or scheduled.finished_req_ids
                or replies.finished_recving
                or replies.kv_connector_worker_meta.completed_saves
            ):
                idle_steps = 0
                continue
            idle_steps += 1
            if idle_steps == 1:
                continue  # a fence or deferred lookup can require one further native step
        if clock.events:
            clock.advance(clock.events[0][0])
            idle_steps = 0
        elif scheduler.has_requests() or live:
            raise ValueError(f"Scheduler stalled at {clock.now} ns; live requests: {list(live)}")
    if len(metrics) != len(admissions.rows) or any(
        "finished_ns" not in m for m in metrics.values()
    ):
        raise ValueError("Incomplete workload or cyclic dependencies")
    return list(metrics.values())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("inputs", type=Path, nargs="+")
    p.add_argument("--output", type=Path, required=True)
    p.add_argument(
        "--offset-s", type=float, action="append", help="One root offset per input (seconds)"
    )
    p.add_argument("--profile", choices=("n15", "reference"), default="n15")
    p.add_argument("--num-blocks", type=int)
    p.add_argument("--max-model-len", type=int)
    p.add_argument("--clients", type=int, choices=(1, 8))
    for budget in ("segment", "staging", "quota"):
        p.add_argument("--" + budget + "-mib", type=int, help="Override per-client capacity in MiB")
    p.add_argument("--offload-delay-ms", type=float, default=1000)
    p.add_argument("--high-watermark", type=float, default=0.90)
    p.add_argument("--eviction-ratio", type=float, default=0.05)
    p.add_argument("--save-ms", type=float, default=1)
    p.add_argument("--lease-ms", type=float, default=0)
    p.add_argument("--device-mib-s", type=float, default=1024)
    p.add_argument("--memory-mib-s", type=float, default=8192)
    p.add_argument("--prefill-ms", type=float, default=10)
    p.add_argument("--decode-ms", type=float, default=2)
    args = p.parse_args()
    os.environ.setdefault("VLLM_SSM_CONV_STATE_LAYOUT", "SD")

    from kv_ssd_sim.deployment import native_deployment
    from kv_ssd_sim.object_worker import metadata_scheduler

    folder = ROOT / "configs/kimi-k3-b300-step2"
    plan, allocation = native_deployment(folder)
    if json.loads(json.dumps(plan)) != json.loads((folder / "resolved.json").read_bytes()):
        raise ValueError("Pinned native K3 geometry changed")
    reference = args.profile == "reference"
    online = json.loads((ROOT / "configs/k3-c1-online.json").read_bytes())
    mc = plan["mooncake"]
    budgets = {
        "segment": mc["global_segment_size_bytes_per_client"],
        "staging": mc["disk_staging_size_bytes_per_client"],
        "quota": plan["ssd"]["offload_quota_bytes_per_client"],
    }
    for name in budgets:
        override = getattr(args, name + "_mib")
        if override is not None:
            budgets[name] = override * MIB
        elif not reference:
            budgets[name] = online[name + "_mib"] * MIB
    config = StoreConfig(
        args.clients or (mc["client_count"] if reference else 1),
        budgets["segment"],
        budgets["staging"],
        budgets["quota"],
        args.offload_delay_ms,
        args.device_mib_s,
        args.memory_mib_s,
        args.lease_ms,
        args.save_ms,
        args.high_watermark,
        args.eviction_ratio,
    )
    blocks = (
        args.num_blocks
        if args.num_blocks is not None
        else (plan["ranks"][0]["native_pool_blocks"] if reference else 22)
    )
    max_len = (
        args.max_model_len if args.max_model_len is not None else (131072 if reference else 12288)
    )
    if (
        blocks < 3
        or max_len < 1
        or any(not math.isfinite(v) or v <= 0 for v in (args.prefill_ms, args.decode_ms))
    ):
        p.error("Invalid scheduler capacity or compute budget")
    offsets = args.offset_s or [0] * len(args.inputs)
    if len(offsets) != len(args.inputs) or any(not math.isfinite(s) or s < 0 for s in offsets):
        p.error("Supply one nonnegative, finite offset per input")
    clock = Clock()
    limit = min(max_len, (blocks - 2) * plan["geometry"]["manager_block_tokens"])
    admissions = Admissions(args.inputs, offsets, clock, limit)
    args.output.mkdir(parents=True, exist_ok=False)
    manifest = {
        "profile": args.profile,
        "num_blocks": blocks,
        "max_model_len": max_len,
        "store": asdict(config),
        "prefill_ms": args.prefill_ms,
        "decode_ms": args.decode_ms,
        "root_offsets_s": offsets,
        "vllm_version": version("vllm"),
        "pythonhashseed": os.environ.get("PYTHONHASHSEED"),
        "geometry_sha256": sha(folder / "resolved.json"),
        "compiled_inputs": [{"file": str(path), "sha256": sha(path)} for path in args.inputs],
    }
    manifest["source_sha256"] = {
        str(p.relative_to(ROOT)): sha(p)
        for p in (
            Path(__file__).resolve(),
            ROOT / "scripts/prepare_object_trace.py",
            ROOT / "scripts/audit_aiperf_input.py",
            *(
                ROOT / "src/kv_ssd_sim" / name
                for name in (
                    "object_traffic.py",
                    "object_store.py",
                    "object_worker.py",
                    "native.py",
                    "k3_online.py",
                    "deployment.py",
                )
            ),
        )
    }
    manifest["service_model"] = (
        "writer-owned, eager offload, byte watermark with eligible LRU, one shared FIFO disk, one memory read port per client"
    )

    def write(name, data):
        (args.output / name).write_text(json.dumps(data, indent=2) + "\n")

    write("launch.json", manifest)
    with (args.output / "events.jsonl").open("w") as f:

        def emit(event, **fields):
            f.write(json.dumps(dict(time_ns=clock.now, event=event, **fields)) + "\n")

        store = ObjectStore(clock, config, emit)
        with metadata_scheduler(store, plan, allocation.kv_cache_groups, blocks, max_len) as (
            scheduler,
            transfers,
        ):
            requests = simulate(
                admissions,
                scheduler,
                transfers,
                store,
                plan["geometry"]["hash_tokens"],
                args.prefill_ms,
                args.decode_ms,
            )
    touches = sum(store.counts[x] for x in ("put_complete", "get_memory", "get_disk"))
    traffic, reuses = describe_traffic(
        args.output / "events.jsonl", args.output / "reuse.jsonl", touches
    )
    for row in requests:
        row["store_traffic"] = traffic.get(row["id"], {"counts": {}, "bytes": {}})
    write("requests.json", requests)
    objects = []
    for k, size in sorted(store.inventory.items()):
        obj = store.objects.get(k)
        objects.append(
            {
                "key": k,
                "bytes": size,
                "owner": obj.owner if obj else None,
                "memory": bool(obj and obj.memory),
                "disk": bool(obj and obj.disk),
            }
        )
    write("objects.json", objects)
    result = dict(
        status="complete",
        cross_request_store_reuses=reuses,
        virtual_end_ns=clock.now,
        requests=len(requests),
        **store.summary(),
    )
    write("summary.json", result)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
